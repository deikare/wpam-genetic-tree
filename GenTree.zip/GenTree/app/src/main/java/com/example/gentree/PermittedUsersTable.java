package com.example.gentree;

public class PermittedUsersTable {
}
