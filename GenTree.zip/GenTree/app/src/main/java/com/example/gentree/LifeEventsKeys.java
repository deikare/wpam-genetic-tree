package com.example.gentree;

public interface LifeEventsKeys {
//    String DATE_OF_BIRTH = "date_of_birth";
    String DATE_OF_DEATH = "date_of_death";
    String EDUCATION = "education";
    String WORK = "work";
    String DESCRIPTION = "description";
    String LOCATION = "location";
}
