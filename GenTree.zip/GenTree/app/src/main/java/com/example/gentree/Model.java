package com.example.gentree;

import org.jgrapht.*;

public class Model {
/*
    Graph<NodeData, String > graph = new D;
*/

}
